<?php
/**
 * Plugin Name: Enable Application Passwords (DEV Full)
 * Description: Habilita Application Passwords e REST API em ambiente HTTP para desenvolvimento.
 * Version: 1.0
 * Author: Essias Souza
 */

/**
 * 1. Força ambiente de desenvolvimento
 */
add_filter( 'wp_get_environment_type', function () {
    return 'development';
});

/**
 * 2. Garante que Application Passwords estejam disponíveis
 */
add_filter( 'wp_is_application_passwords_available', '__return_true' );

/**
 * 3. Permite Application Passwords mesmo sem HTTPS
 */
add_filter( 'application_password_is_api_request', '__return_true' );

/**
 * 4. Garante que a REST API não seja bloqueada
 */
add_filter( 'rest_authentication_errors', function ( $result ) {
    if ( is_wp_error( $result ) ) {
        return null;
    }
    return $result;
});

/**
 * 5. (Opcional) Log para debug
 */
add_action( 'init', function () {
    if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
        error_log( 'Application Passwords DEV plugin ativo' );
    }
});
